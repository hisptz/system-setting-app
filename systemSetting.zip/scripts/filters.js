'use strict';

/* Filters */

var systemSettingFilters = angular.module('systemSettingFilters', []);