//Controller for column show/hide
systemSetting.controller('LeftBarMenuController',
        function($scope, $location) {

});