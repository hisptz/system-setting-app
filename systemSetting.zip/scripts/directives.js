'use strict';

/* Directives */

var systemSettingDirectives = angular.module('systemSettingDirectives', []);