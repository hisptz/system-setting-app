# systemSettingApp

This involve the revamping of the dhis system setting app according to your requirement,
Language used are HTML5,Angular js and CSS

During your installation 
remember to change base url that suit your website
eg if your url is 

http://localhost:8080/genya

the base url should also be changed to 
        
            window.dhis2 = window.dhis2 || {};
            dhis2.settings = dhis2.settings || {};
            dhis2.settings.baseUrl = 'genya';
        
